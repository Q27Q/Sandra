function sayHello(name) {
  const greeting = `你好，${name}！`;
  return greeting;
}
